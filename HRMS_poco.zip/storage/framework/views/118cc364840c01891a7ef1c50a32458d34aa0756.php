<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

                <p><b>Dear   "<?php echo e($supervisor_name); ?>,</b></p>

                <p><?php echo e($candidate_name); ?>  has joined with your department in the role of <?php echo e($candidate_position); ?> as on <?php echo e($doj); ?>, today..</p>
                <p>Please note that Official Email ID is <?php echo e($hr_suggest_email); ?>.  Personal Email ID is <?php echo e($candidate_email); ?>. </p>
                <p>Contact Number is <?php echo e($candidate_mobile); ?> ."Onboarding, Induction & Joining Formalities have been completed and handing over to you.</p>

                <p><b>Thank you,</b></p>
                <p>HR OP.S Team - HEPL</p>



</body>
</html>

<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\emails\ITInfraNewCandidateJoin.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

      
                <p><b>Dear {{$candidate_name}} ,</b></p>

                <p>HR Dept will review the information and approve / revert with comments shortly.</p>

                <p><b>Thank you,</b></p>
                <p> HR Team - HEPL</p>
      


</body>
</html>

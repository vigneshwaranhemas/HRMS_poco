<div class="iconsidebar-menu  iconbar-mainmenu-close">
    <div class="sidebar">
       <ul class="iconMenu-bar custom-scrollbar">
          <li>
             <a class="bar-icons" href="<?php echo e(route('candidate_dashboard')); ?>">
                <!--img(src='../assets/images/menu/home.png' alt='')--><i class="pe-7s-home"></i><span>Dashboard    </span>
             </a>
          </li>
          <li>
             <a class="bar-icons bar-icons-hover" href="#"><i class="pe-7s-portfolio"></i><span>Pre OnBoarding</span></a>
             <ul class="iconbar-mainmenu custom-scrollbar">
                <li class="iconbar-header">Pre OnBoarding</li>
                <li><a href="<?php echo e(url('preOnboarding')); ?>">Pre OnBoarding</a></li>
                <li><a href="<?php echo e(url('Candidate_Induction')); ?>">Induction Schedule</a></li>
                <li><a href="<?php echo e(url('Candidate_Assigned_Buddy')); ?>">Buddy Info </a></li>
                <li><a href="<?php echo e(url('Buddy_feedback')); ?>">Buddy Feedback</a></li>
                <li><a href="<?php echo e(url('view_welcome_aboard')); ?>">Welcome Aboard</a></li>
             </ul>
          </li>
          <li>
             <span class="badge badge-pill badge-danger">Hot</span><a class="bar-icons" href="#"><i class="pe-7s-diamond"></i><span>Profile</span></a>
              <ul class="iconbar-mainmenu custom-scrollbar">
                <li class="iconbar-header">Profile</li>
                <li><a href="<?php echo e(url('../candidate_profile')); ?>">My Profile</a></li>
             </ul>
          </li>

       </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\layouts\simple\candidate_sidebar.blade.php ENDPATH**/ ?>
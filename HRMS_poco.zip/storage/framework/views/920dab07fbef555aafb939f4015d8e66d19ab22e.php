
<?php $__env->startSection('title', 'Document Center'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="../assets/css/prism.css">
    <!-- Plugins css start-->
<link rel="stylesheet" type="text/css" href="../assets/css/chartist.css">
<link rel="stylesheet" type="text/css" href="../assets/css/date-picker.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    .card-body p{
        margin-bottom: 3% !important;
        font-size: 15px !important;
    }
    .card-body td{
        margin-bottom: 3% !important;
        font-size: 15px !important;
        padding-bottom: 43px;
        padding-left: 0px;
    }
    .card-body h5{
        margin-bottom: 3% !important;
    }

    /* input field css start*/
    .input {
    background-color: transparent;
    border: none;
    border-bottom: 1px solid #ccc;
    color: #555;
    box-sizing: border-box;
    font-family: "Arvo";
    font-size: 18px;
    width: 200px;
    color: #008CBA;
    }

    input::-webkit-input-placeholder {
    color: #aaa;
    }

    input:focus::-webkit-input-placeholder {
    color: dodgerblue;
    }

    .input:focus + .underline {
    transform: scale(1);
    }
    /* input field css end*/

    .table td
    {
        border-top: none !important;
    }

    .editor
    {
        margin-left: -49px;
        margin-top: -58px;
    }

    .interesting_facts
    {
        width: 70%;
    }
    .text-warning
    {
        color: #ff0000!important;
    }
    .card-header
    {
        background-color: rgba(0,0,0,0.03) !important;
        padding: 28px !important;
    }
    .card .card-header .card-header-right
    {
        top: 19px !important;
    }
    .card .card-body
    {
        padding: 28px !important;
    }


</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2>Document Center<span> </span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2>Documents</h2>
    <div class="row">
        <div class="col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5> Documents</h5>
                    <div class="card-header-right">
                        <i class="fa fa-file"></i>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-md-12 text-center">
                        <a href="<?php echo e(url('welcome_aboard')); ?>"><button class="btn btn-primary" type="button">View All</button></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5> Payslips</h5>
                    <div class="card-header-right">
                        <i class="fa fa-money"></i>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-md-12 text-center">
                        <a href="<?php echo e(url('payslip')); ?>"><button class="btn btn-primary" type="button">View All</button></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5> Form 16</h5>
                    <div class="card-header-right">
                        <i class="fa fa-file-text"></i>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-md-12 text-center">
                        <a href="<?php echo e(url('welcome_aboard')); ?>"><button class="btn btn-primary" type="button">View All</button></a>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5> Company Policies</h5>
                    <div class="card-header-right">
                        <i class="fa fa-clipboard"></i>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-md-12 text-center">
                        <a href="<?php echo e(url('welcome_aboard')); ?>"><button class="btn btn-primary" type="button">View All</button></a>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5> Forms</h5>
                    <div class="card-header-right">
                        <i class="fa fa-file-text"></i>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-md-12 text-center">
                        <a href="<?php echo e(url('welcome_aboard')); ?>"><button class="btn btn-primary" type="button">View All</button></a>

                    </div>

                </div>
            </div>
        </div>


    </div>
    <h2>Request</h2>
    <div class="row">
        <div class="col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5> Letters</h5>
                    <div class="card-header-right">
                        <i class="fa fa-envelope"></i>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 text-left">
                            <p> Pending: 0</p>
                        </div>
                        <div class="col-md-6 text-right">
                            <p> Closed: 0</p>
                        </div>
                    </div>
                    <div class="col-md-12 text-center">
                        <a href="<?php echo e(url('welcome_aboard')); ?>"><button class="btn btn-primary" type="button">View All</button></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="../assets/pro_js/view_welcome_aboard.js"></script>

<script>
var add_welcome_aboard_process_link = "<?php echo e(url('add_welcome_aboard_process')); ?>";
var get_welcome_aboard_details_link = "<?php echo e(url('get_welcome_aboard_details')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.simple.candidate_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/candidate/document_center.blade.php ENDPATH**/ ?>
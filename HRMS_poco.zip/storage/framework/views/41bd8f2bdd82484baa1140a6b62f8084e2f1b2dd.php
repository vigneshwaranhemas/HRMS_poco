<div class="iconsidebar-menu iconbar-mainmenu-close">
   <div class="sidebar">
      <ul class="iconMenu-bar custom-scrollbar">
         <li>
            <a class="bar-icons" href="<?php echo e(route('admin_dashboard')); ?>">
               <!--img(src='../assets/images/menu/home.png' alt='')--><i class="pe-7s-home"></i><span>Dashboard    </span>
            </a>
         </li>
         <li>
            <a class="bar-icons bar-icons-hover" href="#"><i class="pe-7s-portfolio"></i><span>Masters</span></a>
            <ul class="iconbar-mainmenu custom-scrollbar">
               <li class="iconbar-header">Masters</li>
               <li><a href="<?php echo e(route('employee_list')); ?>">Employee List</a></li>
               <li><a href="<?php echo e(route('business')); ?>">Business Unit</a></li>
               <li><a href="<?php echo e(route('division')); ?>">Division</a></li>
               <li><a href="<?php echo e(route('function')); ?>">Function </a></li>
               <li><a href="<?php echo e(route('grade')); ?>">Grade</a></li>
               <li><a href="<?php echo e(route('band')); ?>">Band</a></li>
               <li><a href="<?php echo e(route('location')); ?>">Work Location</a></li>
               <li><a href="<?php echo e(route('blood')); ?>">Blood Group</a></li>
               <li><a href="<?php echo e(route('roll')); ?>">Roll of Intake</a></li>
               <li><a href="<?php echo e(route('department')); ?>">Department</a></li>
               <li><a href="<?php echo e(route('designation_or_position')); ?>">Designation or Position</a></li>
               <li><a href="<?php echo e(route('client')); ?>">Client</a></li>
               <li><a href="<?php echo e(route('state')); ?>">State</a></li>
               <li><a href="<?php echo e(route('zone')); ?>">Zone</a></li>
            </ul>
         </li>
         <li>
            <a class="bar-icons bar-icons-hover" href="#"><i class="pe-7s-target"></i><span>Goals</span></a>
            <ul class="iconbar-mainmenu custom-scrollbar">
               <li class="iconbar-header">Goals</li>
                <li><a href="<?php echo e(route('goals')); ?>">Goals</a></li>
               <li><a href="<?php echo e(route('goal_setting')); ?>">Goal Setting</a></li>
            </ul>
         </li>         
         <li>
            <a class="bar-icons" href="<?php echo e(route('holidays')); ?>"><i class="pe-7s-plane"></i><span>Holidays</span></a>
         </li>
         <li>
            <a class="bar-icons" href="<?php echo e(route('events')); ?>"><i class="pe-7s-note"></i><span>Events</span></a>
         </li>
         <li>
            <a class="bar-icons bar-icons-hover" href="#"><i class="pe-7s-note2"></i><span>Settings</span></a>
             <ul class="iconbar-mainmenu custom-scrollbar">
               <li class="iconbar-header">Settings</li>
               <li><a>Profile Settings</a></li>
               <li><a href="<?php echo e(url('/permission')); ?>">Roles & Permissions</a></li>
               <li><a>Function</a>Module Settings</li>
            </ul>
         </li>
      </ul>
   </div>
</div>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\layouts\simple\admin_sidebar.blade.php ENDPATH**/ ?>
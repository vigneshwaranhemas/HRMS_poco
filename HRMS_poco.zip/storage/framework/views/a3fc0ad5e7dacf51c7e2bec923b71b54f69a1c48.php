
<?php $__env->startSection('title', 'Pre OnBoarding'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url("assets/css/datatables.css")); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/datatable-extension.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2><span>Pre OnBoarding </span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">Pre OnBoarding</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
               <div class="card-body">
                  <div class="dt-ext table-responsive">
                     <table class="display" id="export-button">
                        <thead>
                           <tr>
                              <th>#</th>
                              <th>Employee Id</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Mobile Number</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        <tbody>
                            <?php if(count($info['user_info']) > 0): ?>
                            <?php $i=0;?>
                             <?php $__currentLoopData = $info['user_info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($item->email===""): ?>
                                     <?php
                                        $email="--";
                                       ?>
                                   <?php else: ?>
                                   <?php
                                        $email=$item->email;
                                      ?>
                                   <?php endif; ?>
                                  <?php if($item->contact_no==""): ?>
                                      <?php
                                      $mobile="--";
                                      ?>
                                  <?php else: ?>
                                       <?php
                                       $mobile=$item->contact_no;
                                       ?>
                                  <?php endif; ?>
                           <tr>
                              <td><?php echo e($i+1); ?></td>
                              <td><?php echo e($item->empID); ?></td>
                              <td><?php echo e($item->username); ?></td>
                              <td><?php echo e($email); ?></td>
                              <td><?php echo e($mobile); ?></td>
                              <td>
                                <button onclick=viewBuddyModel("<?php echo e($item->empID); ?>")  aria-expanded="false"  class="btn btn-default waves-effect waves-light" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                            </td>
                           </tr>
                           <?php $i++;?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>

                     <?php endif; ?>
                           
                        </tbody>
                     </table>
                     <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" id="token">

                  </div>
               </div>
            </div>
         </div>

    </div>
</div>



<div class="modal fade" id="projectTimerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none">
    <div class="modal-dialog" role="document">
       <div class="modal-content">

          <div class="modal-body">
            <table class="table admin-table table-hover">
                <thead>
                    <tr>
                        <th  colspan="3">Pre OnBoarding</th>
                    </tr>
                </thead>
                <tbody id="candidate_onboardinfo">
                </tbody>
            </table>
          </div>
          <div class="modal-footer">
             <button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>
          </div>
       </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../pro_js/Hrss/hrpreonboarding.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.simple.hr_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\HRSS\preOnboarding.blade.php ENDPATH**/ ?>
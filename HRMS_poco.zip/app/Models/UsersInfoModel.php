<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsersInfoModel extends Model
{
    protected $gaurded=[];
    protected $table="users";
}

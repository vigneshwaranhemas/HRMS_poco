<?php
$sess_info=Session::get("session_info");

?>

<?php $__env->startSection('title', 'Buddy Feedback'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/prism.css')); ?>">
    <!-- Plugins css start-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
.table th
{
    width:1px;
}
.table th
{
    border: 1px solid #dee2e6;
}
.table td
{
    border: 1px solid #dee2e6;
}
.buddy_list
{
    padding-bottom: 50px;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2>Buddy<span>Feedback </span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">Buddy Feedback</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
          <div class="card">
               <div class="card-body">
                  <div class="row buddy_list">
                     <div class="col-md-3">
                        <p>Employee Number</p>
                        <p>Employee Name</p>
                        <p>Department</p>
                        <p>Designation</p>
                        <p>Date of Joining</p>
                        <p>Work Location</p>
                        <p>Buddy Assigned </p>
                    </div>
                    <div class="col-md-3" style="margin-left: -53px;">
                        <?php $__currentLoopData = $buddy_fields["user_info"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p>: <?php echo e($item->cdID); ?> </p>
                            <p>: <?php echo e($item->candidate_name); ?></p>
                            <p>: <?php echo e($item->or_department); ?> </p>
                            <p>: PHP Developer</p>
                            <p>: <?php echo e($item->or_doj); ?></p>
                            <p>: Cuddalore</p>
                            <p>: SHANTHI</p>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                  </div>
                  <div class="modal-body" style="margin-left: -14px;">
                    <table class="table table-custom dtable-striped table-bordered" style="width: max-content;" id="buddy_feedbacktable">
                        <thead>
                          <tr>
                            <th scope="col" rowspan="2">S.No</th>
                            <th scope="col" rowspan="2">Question / Query</th>
                            <th scope="col" colspan="5" class="text-center">Response</th>
                          </tr>
                          <tr>
                            <th scope="col">STRONGLY DISAGREE</th>
                            <th scope="col">DISAGREE</th>
                            <th scope="col">NEITEHR AGREE NOR DISAGREE</th>
                            <th scope="col">AGREE</th>
                            <th scope="col">STRONGLY AGREE</th>
                            <th scope="col">Remarks</th>
                          </tr>
                        </thead>
                        <tbody>

                            <?php $i=0;?>
                            <?php $__currentLoopData = $buddy_fields["fields"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i<=5): ?>
                            <tr class="countable_rows">
                            <td><?php echo e($i+1); ?></td>
                            <td><?php echo e($fields->Buddy_feedback_fields); ?>

                                <input type="hidden" id="field<?php echo e($fields->id); ?>" value="<?php echo e($fields->id); ?>">
                            </td>

                             <?php if(count($buddy_fields["feedback_info"]) > 0): ?>
                                <td class="text-center"><input type="checkbox" <?php echo e($buddy_fields['feedback_info'][$i]->response == 1 ? 'checked' : ''); ?> value="1"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?>  checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox" <?php echo e($buddy_fields['feedback_info'][$i]->response == 2 ? 'checked' : ''); ?> value="2"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>")  class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox" <?php echo e($buddy_fields['feedback_info'][$i]->response == 3 ? 'checked' : ''); ?> value="3"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox" <?php echo e($buddy_fields['feedback_info'][$i]->response == 4 ? 'checked' : ''); ?> value="4"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox" <?php echo e($buddy_fields['feedback_info'][$i]->response == 5 ? 'checked' : ''); ?> value="5"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td>
                                    <textarea style="width: 178px; height:52px;"><?php echo e($buddy_fields['feedback_info'][$i]->remarks); ?></textarea>
                                </td>
                                </tr>
                             <?php else: ?>
                                <td class="text-center"><input type="checkbox"  value="1"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?>  checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox"  value="2"  onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>")  class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox"  value="3"  onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>")  class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox"  value="4"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td class="text-center"><input type="checkbox"  value="5"   onclick=checkbox_validator(this,"buddy<?php echo e($i); ?>") class="buddy<?php echo e($i); ?> checkboxchecker" name="buddy<?php echo e($i); ?>"></td>
                                <td><textarea style="width: 178px; height:52px;"></textarea></td>

                               </tr>
                             <?php endif; ?>

                            <?php endif; ?>

                             <?php  $i++;?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                      </table>



                </div>
                <div class="modal-body">

                    <?php $i=0;?>
                    <?php $__currentLoopData = $buddy_fields["fields"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i>5): ?>
                    <div class="row">
                        <?php if(count($buddy_fields["feedback_info"]) > 0): ?>
                            <div class="col-sm-12" id="target<?php echo e($fields->id); ?>">
                                <p> <?php echo e($i+1); ?>).  <?php echo e($fields->Buddy_feedback_fields); ?></p>
                                <input type="hidden" id="field<?php echo e($fields->id); ?>"  value="<?php echo e($fields->id); ?>"></td>
                             <div class="form-group row">
                                <div class="col-sm-4">
                                    <textarea><?php echo e($buddy_fields['feedback_info'][$i]->comments0); ?></textarea>
                                </div>
                                <div class="col-sm-4">
                                    <textarea><?php echo e($buddy_fields['feedback_info'][$i]->comments1); ?></textarea>
                                </div>
                                <div class="col-sm-4">
                                    <textarea><?php echo e($buddy_fields['feedback_info'][$i]->comments2); ?></textarea>
                                </div>
                             </div>
                            </div>
                           <?php else: ?>
                            <div class="col-sm-12" id="target<?php echo e($fields->id); ?>">
                                <p> <?php echo e($i+1); ?>).  <?php echo e($fields->Buddy_feedback_fields); ?></p>
                                <div class="form-group row">
                                <input type="hidden" id="field<?php echo e($fields->id); ?>"  value="<?php echo e($fields->id); ?>"></td>
                                <div class="col-sm-4">
                                    <textarea></textarea>
                                </div>
                                <div class="col-sm-4">
                                    <textarea></textarea>
                                </div>
                                <div class="col-sm-4">
                                    <textarea></textarea>
                                </div>
                                </div>
                            </div>
                    <?php endif; ?>
                </div>

                    <?php endif; ?>
                     <?php
                     $i++;?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="text-center moves">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" id="token">
                    <input type="hidden" value=<?php echo e($sess_info["empID"]); ?>  id="sess_emp_id">
                        <button type="button" id="BuddyFeedbackBtn" style="display:none;" class="btn btn-info">Submit</button>
                </div>



               </div>


          </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../pro_js/preonboarding/preonboarding.js"></script>
<script>

var fields_info=<?php echo json_encode($buddy_fields["fields"], 15, 512) ?>;


$(()=>{
      var data=<?php echo json_encode($buddy_fields["feedback_info"], 15, 512) ?>;
      if(data.length>0)
      {
           $("#BuddyFeedbackBtn").hide();
      }
      else{
          $('#BuddyFeedbackBtn').show();
      }
})

function checkbox_validator(one,two){
    $('.'+two).not(one).prop('checked', false);
}


</script>


<?php echo $__env->make('layouts.simple.candidate_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/candidate/buddy_feedback.blade.php ENDPATH**/ ?>
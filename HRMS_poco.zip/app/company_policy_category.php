<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company_policy_category extends Model
{
    protected $guarded = [];
    protected $table = "company_policy_categories";
}

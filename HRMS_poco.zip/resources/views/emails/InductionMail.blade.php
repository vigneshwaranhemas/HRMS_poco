<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

      <p><b>"Dear {{$candidate_name}}", Congratulations!</b></p>

      <p>Welcome to the team! We are excited to have you at HEPL<br> - Group Company of CavinKare.</p>

      <p>We believe that you will grow to be a valuable asset to our company <br> and we are looking forward to the positive impact you're about to create.</p>

      <p>On behalf of all the members and the management, we would like to <br> extend our warmest welcome and good wishes!</p>

      <p>Please login to http://hub1.cavinkare.in/CK_Academy/login/index.php to <br> access CK Academy LMS portal and login using credentials mentioned below. </p>

      <p>User Name -  "{{$username}}" Password -  "{{$password}}"</p>

      <p>Kindly complete the HR induction & CK Swagatham and share status once completed.</p>

      <p><b>Thank you,</b></p>
      <p>HR OP.S Team - HEPL</p>




</body>
</html>

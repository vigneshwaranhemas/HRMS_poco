<style>
   .page-wrapper .page-body-wrapper .iconsidebar-menu .iconMenu-bar
   {
      height: calc(116vh - 80px) !important;
   }
   .page-wrapper .page-body-wrapper .iconsidebar-menu
   {
      top: 65px !important;
   }
</style>
<div class="iconsidebar-menu iconbar-mainmenu-close">
    <div class="sidebar">
       <ul class="iconMenu-bar custom-scrollbar" id="sidebar_data">
                
       </ul>
    </div>
 </div>

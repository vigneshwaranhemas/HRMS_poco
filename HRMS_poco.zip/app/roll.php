<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class roll extends Model
{
    protected $gaurded = [];
    protected $table = "rolls";
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class welcome_aboard extends Model
{
    protected $guarded = [];
    protected $table = "welcome_aboards";
}

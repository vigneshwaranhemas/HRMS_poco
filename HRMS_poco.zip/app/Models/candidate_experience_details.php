<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class candidate_experience_details extends Model
{
    protected $gaurded=[];
    protected $table="candidate_experience_details";
}

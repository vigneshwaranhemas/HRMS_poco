
<?php $__env->startSection('title', 'Mega Menu'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="../assets/css/permission.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
   <h2>Roles <span>& Permission</span></h2>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">HRMS</li>
   <li class="breadcrumb-item">Settings</li>
   <li class="breadcrumb-item active">Roles & Permission</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <a  href="<?php echo e(url('roles_s')); ?>"><button id="addRole" class="btn btn-danger waves-effect waves-light" type="button" data-toggle="modal">Manage Role</button></a>
    <br>
    <br>
<div class="container-fluid">
   <div class="row">
      <div class="col-sm-12">
         <div class="card">
            <div class="white-box">
              <div class="row">
                  <div class="col-md-12  menu_list" id="test">
                    <table  id='premission_tbody"+index+"'>
                    </table>
                  </div>
              </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<!-- Common JS -->
<script src="../pro_js/admin/permission.js"></script>

<script type="text/javascript">
   $( document ).ready(function() {
          $.ajaxSetup({
              headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });
      });
    var get_permision_role_link = "<?php echo e(url('role_list')); ?>";
    var get_menu_link = "<?php echo e(url('menu_listing')); ?>";
    var get_sub_menu_save_link = "<?php echo e(url('sub_menu_save_tab')); ?>";
</script>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.simple.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\admin\permission.blade.php ENDPATH**/ ?>
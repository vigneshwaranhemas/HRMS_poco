
<?php $__env->startSection("title", "User Documents "); ?>

<?php $__env->startSection("css"); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url("assets/css/datatables.css")); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url("assets/css/datatable-extension.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("style"); ?>
<?php $__env->stopSection(); ?>
<style>
.test{
    width:16%;
}
 </style>
<?php $__env->startSection("breadcrumb-title"); ?>
	<h2><span>User Documents  </span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("breadcrumb-items"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="card-body">
   <div class="row people-grid-row">
        <?php if(count(array($user_documents))>0): ?>
             <?php if(!empty($user_documents->education_details)): ?>
                <div class="col-md-3 col-lg-3 col-xl-4">
                    <div class="card widget-profile" style="width: 100%;height: 90%;"">
                        <div class="card-body rounded" style="box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
                            <div class="pro-widget-content text-center">
                                <div class="profile-info-widget" style="margin-bottom: -37px;">
                                    <a class="fa fa-suitcase" style="font-size:25px;color:black"></a>
                                    <div class="profile-det-info">
                                        <h5><a href='<?php echo e(url('Documents/'.$user_documents->education_details)); ?>' target="_blank" class="text-info">Education</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
            <?php endif; ?>

             <?php if(!empty($user_documents->experience)): ?>
                <div class="col-md-3 col-lg-3 col-xl-4">
                    <div class="card widget-profile" style="width: 100%;height: 90%;"">
                        <div class="card-body rounded" style="box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
                            <div class="pro-widget-content text-center">
                                <div class="profile-info-widget" style="margin-bottom: -37px;">
                                    <a class="fa fa-suitcase" style="font-size:25px;color:black"></a>
                                    <div class="profile-det-info">
                                        <h5><a href='<?php echo e(url('Documents/'.$user_documents->experience)); ?>' class="text-info">Experience</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(!empty($user_documents->benefites)): ?>
                <div class="col-md-3 col-lg-3 col-xl-4">
                    <div class="card widget-profile" style="width: 100%;height: 90%;"">
                        <div class="card-body rounded" style="box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
                            <div class="pro-widget-content text-center">
                                <div class="profile-info-widget" style="margin-bottom: -37px;">
                                    <a class="fa fa-suitcase" style="font-size:25px;color:black"></a>
                                    <div class="profile-det-info">
                                        <h5><a href='<?php echo e(url('Documents/'.$user_documents->benefites)); ?>' class="text-info">Benefits</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(!empty($user_documents->documents)): ?>
                <div class="col-md-3 col-lg-3 col-xl-4">
                    <div class="card widget-profile" style="width: 100%;height: 90%;"">
                        <div class="card-body rounded" style="box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
                            <div class="pro-widget-content text-center">
                                <div class="profile-info-widget" style="margin-bottom: -37px;">
                                    <a class="fa fa-suitcase" style="font-size:25px;color:black"></a>
                                    <div class="profile-det-info">
                                        <h5><a href='<?php echo e(url('Documents/'.$user_documents->doc_path)); ?>' class="text-info"><?php echo e($user_documents->documents); ?></a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
     <?php endif; ?>
    </div>
</div>
<div class="form-group test">
    <label for="exampleFormControlSelect7">Status</label>
    <?php if(count((array)$user_documents)>0): ?>
        <select class="form-control btn-pill digits" id="userDocStatus">
       <option  <?php echo e($user_documents->doc_status == 0 ? 'selected' :''); ?> value="0">Choose</option>
       <option  <?php echo e($user_documents->doc_status == 2 ? 'selected' :''); ?> value="2">Verified</option>
       <option  <?php echo e($user_documents->doc_status == 1 ? 'selected' :''); ?> value="1">Partitally Verified</option>
    </select><br>
    <?php else: ?>
    <select class="form-control btn-pill digits" id="userDocStatus">
        <option value="0">Choose</option>
        <option  value="2">Verified</option>
        <option  value="1">Partitally Verified</option>
     </select><br>
     <?php endif; ?>
   <button type="button" class="btn btn-primary" id="DocStatusBtn">Submit</button>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<script>
    var DocumentStatusurl="<?php echo e(url('DocumentStatusUpdate')); ?>";
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../pro_js/Hrss/OnBoarding.js"></script>

<?php echo $__env->make("layouts.simple.hr_master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\HRSS\userdocuments.blade.php ENDPATH**/ ?>
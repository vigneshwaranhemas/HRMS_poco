<?php
$session_val = Session::get('session_info');
        $passcode_status = $session_val['passcode_status'];
?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<div class="page-main-header">
  <div class="main-header-right">
    <div class="main-header-left text-center">
         <?php if($passcode_status==0): ?>
           <div class="logo-wrapper"><a href="<?php echo e(url('change_password')); ?>"><img src="../assets/images/logo/logo.png" alt=""></a></div>
         <?php else: ?>
           <div class="logo-wrapper"><a href="<?php echo e(url('com_dashboard')); ?>"><img src="../assets/images/logo/logo.png" alt=""></a></div>
         <?php endif; ?>
    </div>
    <div class="mobile-sidebar">
      <div class="media-body text-right switch-sm">
        <label class="switch ml-3"><i class="font-primary" id="sidebar-toggle" data-feather="align-center"></i></label>
      </div>
    </div>
    <div class="vertical-mobile-sidebar"><i class="fa fa-bars sidebar-bar">               </i></div>
    <div class="nav-right col pull-right right-menu">
      <ul class="nav-menus">
        <li>
        </li>
        <li><a class="text-dark" href="#!" onclick="javascript:toggleFullScreen()"><i data-feather="maximize"></i></a></li>
        <li class="onhover-dropdown"><img class="img-fluid img-shadow-warning" src="../assets/images/dashboard/notification.png" alt="">
          <ul class="onhover-show-div notification-dropdown">
            <li class="gradient-primary">
              <h5 class="f-w-700">Notifications</h5><span>You have 6 unread messages</span>
            </li>
            <li>
              <div class="media">
                <div class="notification-icons bg-success mr-3"><i class="mt-0" data-feather="thumbs-up"></i></div>
                <div class="media-body">
                  <h6>Someone Likes Your Posts</h6>
                  <p class="mb-0"> 2 Hours Ago</p>
                </div>
              </div>
            </li>
            <li class="pt-0">
              <div class="media">
                <div class="notification-icons bg-info mr-3"><i class="mt-0" data-feather="message-circle"></i></div>
                <div class="media-body">
                  <h6>3 New Comments</h6>
                  <p class="mb-0"> 1 Hours Ago</p>
                </div>
              </div>
            </li>
            <li class="bg-light txt-dark"><a href="#">All </a> notification</li>
          </ul>
        </li>
        <li><a class="right_side_toggle" href="#"><img class="img-fluid img-shadow-success" src="../assets/images/dashboard/chat.png" alt=""></a></li>
        <li class="onhover-dropdown"> <span class="media user-header" id="login_profile_image"></span>
          <ul class="onhover-show-div profile-dropdown">
            <li class="gradient-primary">
              <h5 class="f-w-600 mb-0"><?php echo e(Auth::user()->username); ?></h5><span><?php echo e(Auth::user()->designation); ?></span>
            </li>
            <!-- <li class="sub_header"><i data-feather="user"> <a href="<?php echo e(url('candidate_profile')); ?>"></i>Profile</a></li> -->
            <li class="sub_header"><i data-feather=""> <a href="<?php echo e(url('candidate_profile')); ?>"></i>Profile</a></li>
            <li class="sub_header"><i data-feather=""><a href="<?php echo e(url('change_password')); ?>"> </i>Change password</a></li>
            <li class="logout"><a href="<?php echo e(url('logout')); ?>"><i data-feather="bi bi-door-closed-fill"> </i><span>Logout</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="d-lg-none mobile-toggle pull-right"><i data-feather="more-horizontal"></i></div>
    </div>
    <script id="result-template" type="text/x-handlebars-template">
      <div class="ProfileCard u-cf">
      <div class="ProfileCard-avatar"><i class="pe-7s-home"></i></div>
      <div class="ProfileCard-details">
      <div class="ProfileCard-realName"><?php echo e(@name); ?></div>
      </div>
      </div>
    </script>
    <script id="empty-template" type="text/x-handlebars-template"><div class="EmptyMessage">Your search turned up 0 results. This most likely means the backend is down, yikes!</div></script>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\layouts\simple\header.blade.php ENDPATH**/ ?>
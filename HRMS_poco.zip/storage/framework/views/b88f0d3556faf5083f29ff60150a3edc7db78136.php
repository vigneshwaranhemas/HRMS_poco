<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

      
                <p><b>Dear Team,</b></p>

                


                <p>Please note that <?php echo e($candidate_name); ?>is joining with HEPL in <?php echo e($candidate_department); ?>" team.</p>
                <p>Please take advise of Supervisor - "<?php echo e($supervisor_name); ?>." </p>
                <p> to allot seat for them before his/her Date of Joining that is "<?php echo e($candidate_doj); ?>".</p>
                <p>Kindly let me know once completed.</p>

                <p><b>Thank you,</b></p>
                <p>HR OP.S Team - HEPL</p>
      


</body>
</html>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\emails\AdminMail.blade.php ENDPATH**/ ?>
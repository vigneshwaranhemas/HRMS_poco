
<?php $__env->startSection('title', 'Day Zero'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url("assets/css/datatables.css")); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/datatable-extension.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2><span>Day Zero</span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">Day Zero</li>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
               <div class="card-body">
                  <div class="dt-ext table-responsive">
                    <table class="display" id="export-button">
                        <thead>
                           <tr>
                              <th>#</th>
                              <th>Employee Id</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Mobile Number</th>
                              <th>Induction Mail</th>
                              <th>Buddy Mail</th>

                           </tr>
                        </thead>
                        <tbody>
                                  <?php if(count($candidate_info) > 0): ?>
                                  <?php $i=1;?>
                                <?php $__currentLoopData = $candidate_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($info["empID"]); ?></td>
                                    <td><?php echo e($info["username"]); ?></td>
                                    <td><?php echo e($info["email"]); ?></td>
                                    <td><?php echo e($info["contact_no"]); ?></td>
                                    <?php if($info["Induction_mail"]==1): ?>
                                    <?php $color="green";?>
                                    <?php $class="fa-check";?>
                                   <?php else: ?>
                                     <?php $class="fa-times";?>
                                     <?php $color="red"; ?>
                                   <?php endif; ?>

                                   <?php if($info["Buddy_mail"]==1): ?>
                                   <?php $color1="green";?>
                                   <?php $class1="fa-check";?>
                                  <?php else: ?>
                                    <?php $class1="fa-times";?>
                                    <?php $color1="red";?>
                                  <?php endif; ?>
                                  <td><p style="color:<?php echo e($color); ?>" class="fa <?php echo e($class); ?>"></p></td>
                                  <td><p style="color:<?php echo e($color1); ?>" class="fa <?php echo e($class1); ?>"></p></td>
                                </tr>
                                <?php $i++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  <?php else: ?>

                                  <?php endif; ?>

                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.simple.hr_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\HRSS\Day_zero.blade.php ENDPATH**/ ?>
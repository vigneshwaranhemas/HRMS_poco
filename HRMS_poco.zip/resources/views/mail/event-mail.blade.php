<h4>{{ $event_name }}</h4>
<p>Place: {{ $where }}</p>
<p>Start event: {{ $start_date_time }}</p>
<p>End event: {{ $end_date_time }}</p>
<p>Event type: {{ $event_type }}</p>
<p>Event category: {{ $category_name }}</p>
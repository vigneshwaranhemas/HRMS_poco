<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class division extends Model
{
    protected $gaurded = [];
    protected $table = "divisions";
}

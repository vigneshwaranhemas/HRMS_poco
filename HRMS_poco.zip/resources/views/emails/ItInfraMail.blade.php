<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
                <p><b>Dear Team,</b></p>

                <p>Dear IT team, Please create Email ID for "{{$candidate_name}}" who is joining with HEPL today" team.</p>
                <p>He is working from Site / Home. Please add his Email ID to suitable mailing groups and update once completed. </p>
                <p>Kindly let me know once completed.</p>

                <p><b>Thank you,</b></p>
                <p>HR OP.S Team - HEPL</p>

</body>
</html>

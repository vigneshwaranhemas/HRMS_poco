<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class  candidate_education_details extends Model
{
    protected $gaurded = [];
    protected $table = "candidate_education_details";
}

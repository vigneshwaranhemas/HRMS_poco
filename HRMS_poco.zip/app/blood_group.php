<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class blood_group extends Model
{
    protected $gaurded = [];
    protected $table = "blood_groups";
}

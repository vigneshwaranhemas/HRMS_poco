<h4>Dear <?php echo e($name); ?></h4>
<p>Sheet submitted successfully!</p><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/mail/goal-emp-mail.blade.php ENDPATH**/ ?>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Candidate_Details extends Model
{
    protected $gaurded=[];
    protected $table="candidate_details";
}

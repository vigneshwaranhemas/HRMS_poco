
<?php $__env->startSection('title', 'Mega Menu'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2>Mega<span>menu</span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
	<li class="breadcrumb-item">Perk UI    </li>
   <li class="breadcrumb-item">Menu Options</li>
   <li class="breadcrumb-item active">Mega Menu</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
   <div class="row">
      <div class="col-sm-12">
         <div class="card alert alert-primary" role="alert">
            <h4 class="alert-heading">Tip!</h4>
            <p>
               When you want to set the mega menu vertically, than use this Page Layout and you will easily be able to set the
               mega menu.
            </p>
         </div>
      </div>
      <div class="col-sm-12">
         <div class="card">
            <div class="card-header">
               <h5>How to use it?</h5>
               <div class="card-header-right">
                  <ul class="list-unstyled card-option">
                     <li><i class="icofont icofont-simple-left"></i></li>
                     <li><i class="view-html fa fa-code"></i></li>
                     <li><i class="icofont icofont-maximize full-card"></i></li>
                     <li><i class="icofont icofont-minus minimize-card"></i></li>
                     <li><i class="icofont icofont-refresh reload-card"></i></li>
                     <li><i class="icofont icofont-error close-card"></i></li>
                  </ul>
               </div>
            </div>
            <div class="card-body">
               <h5>Step 1</h5>
               <p>Include vertical-menu.js, vertical-menu.css, megamenu.js</p>
               <h5>Step 2</h5>
               <p>If we want to drilldown pattern add in mega menu portion you have to include also jquery.drilldown.js</p>
               <h5>Step 3</h5>
               <p>Copy html code of vertical-menu-main according to your requirement in this layout.</p>
               <h5>Step 4</h5>
               <p class="mb-0">Finally, you can change the content according to your need.</p>
               <div class="code-box-copy">
                  <button class="code-box-copy__btn btn-clipboard" data-clipboard-target="#example-head" title="Copy"><i class="icofont icofont-copy-alt"></i></button>
                  <pre><code class="language-html" id="example-head">&lt;!-- Cod Box Copy begin --&gt;
&lt;div class=&quot;card-body&quot;&gt;
&lt;h5&gt;Step 1&lt;/h5&gt;
&lt;p&gt;Include vertical-menu.js, vertical-menu.css, megamenu.js&lt;/p&gt;
&lt;h5&gt;Step 2&lt;/h5&gt;
&lt;p&gt;If we want to drilldown pattern add in mega menu portion you have to include also jquery.drilldown.js&lt;/p&gt;
&lt;h5&gt;Step 3&lt;/h5&gt;
&lt;p&gt;Copy html code of vertical-menu-main according to your requirement in this layout.&lt;/p&gt;
&lt;h5&gt;Step 4&lt;/h5&gt;
&lt;p&gt;Finally, you can change the content according to your need.&lt;/p&gt;
&lt;/div&gt;
&lt;!-- Cod Box Copy end --&gt;</code></pre>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.mega.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\perk-ui\mega-menu.blade.php ENDPATH**/ ?>
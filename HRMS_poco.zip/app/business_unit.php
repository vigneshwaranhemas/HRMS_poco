<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class business_unit extends Model
{
    protected $gaurded = [];
    protected $table = "business_unit";
}

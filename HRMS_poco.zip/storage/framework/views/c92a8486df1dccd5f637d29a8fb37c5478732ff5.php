<?php $__currentLoopData = $sticky_note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="stickyBox_<?php echo e($note->id); ?>" class="col-md-12 sticky-note"  style='margin-top: 12px;'>
        <div class="well
             <?php if($note->color == 'red'): ?>
                bg-danger
             <?php endif; ?>
        <?php if($note->color == 'green'): ?>
                bg-success
             <?php endif; ?>
        <?php if($note->color == 'yellow'): ?>
                bg-warning
             <?php endif; ?>
        <?php if($note->color == 'blue'): ?>
                bg-info
             <?php endif; ?>
        <?php if($note->color == 'purple'): ?>
                bg-primary
             <?php endif; ?>
                b-none">
            <p  style='padding-top: 24px; margin-left: 24px;'><?php echo nl2br($note->Notes); ?></p>
            <hr>
            <div class="row font-12">
                <div class="col-xs-9"  style='margin-left: 39px;margin-bottom: 17px;'>
                    Updated: <?php echo e($Time->diffForHumans($note->updated_at,true)." ".'ago'); ?>

                </div>
                <div class="col-xs-3" style="margin-left: 38px;">
                    <a href="javascript:;"  onclick="showEditNoteModal(<?php echo e($note->id); ?>)"><i class="fa fa-pencil text-white"></i></a>
                    <a href="javascript:;" class="m-l-5" onclick="deleteSticky(<?php echo e($note->id); ?>)" ><i class="fa fa-trash text-white"></i></a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/Sticky_notes/note-ajax.blade.php ENDPATH**/ ?>
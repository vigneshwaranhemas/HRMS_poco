<div class="iconsidebar-menu  iconbar-mainmenu-close">
    <div class="sidebar">
       <ul class="iconMenu-bar custom-scrollbar">
          <li>
             <a class="bar-icons" href="<?php echo e(route('hr_dashboard')); ?>">
                <!--img(src='../assets/images/menu/home.png' alt='')--><i class="pe-7s-home"></i><span>Dashboard    </span>
             </a>
          </li>
          <li>
             <a class="bar-icons  bar-icons-hover" href="#"><i class="pe-7s-portfolio"></i><span>Pre OnBoarding  </span></a>
             <ul class="iconbar-mainmenu custom-scrollbar">
                <li class="iconbar-header">Pre OnBoarding</li>
                <li><a href="<?php echo e(url('hrsspreOnboarding')); ?>">Pre OnBoarding</a></li>
                <li><a href="<?php echo e(url('hrssdayzero')); ?>">Day Zero</a></li>
                <li><a href="<?php echo e(url('hrssOnBoarding')); ?>">On Boarding </a></li>
                <li><a href="<?php echo e(url('seating_readiness')); ?>">Seating  & IdCard Request </a></li>
                <li><a href="<?php echo e(url('EmailIdCreation')); ?>">Email IdCreation </a></li>
             </ul>
          </li>
          <li>
             <span class="badge badge-pill badge-danger"></span><a class="bar-icons"  href="<?php echo e(url('hrssCandidate')); ?>"><i class="pe-7s-diamond"></i><span>Candidate</span></a>

          </li>
          <li>
             <a class="bar-icons" href="#"><i class="pe-7s-note2"></i><span>Profile</span></a>

          </li>

          <li>
             <a class="bar-icons bar-icons-hover" href="#"><i class="pe-7s-target"></i><span>Goals </span></a>
             <ul class="iconbar-mainmenu custom-scrollbar">
                <li class="iconbar-header">Goals</li>
                <li><a href="<?php echo e(route('goals')); ?>">Goals</a></li>
               <li><a href="<?php echo e(route('goal_setting')); ?>">Goal Setting</a></li>
             </ul>
          </li>
         <li>
            <a class="bar-icons" href="<?php echo e(route('holidays')); ?>"><i class="pe-7s-plane"></i><span>Holidays</span></a>
         </li>
         <li>
            <a class="bar-icons" href="<?php echo e(route('events')); ?>"><i class="pe-7s-note"></i><span>Events</span></a>
         </li>             
       </ul>
    </div>
 </div>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\layouts\simple\hr_sidebar.blade.php ENDPATH**/ ?>
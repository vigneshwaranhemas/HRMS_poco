
<?php $__env->startSection('title', 'User Cards'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2>My<span>Teams</span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
	<li class="breadcrumb-item">Apps</li>
   <li class="breadcrumb-item">User</li>
	<li class="breadcrumb-item active">My Teams</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
   <div class="row" id="my_teams">
      
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="../pro_js/my_team.js"></script>
<script type="text/javascript">
   $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var my_team_tl_link = "<?php echo e(url('my_team_tl_info')); ?>";
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.simple.candidate_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/my_team.blade.php ENDPATH**/ ?>
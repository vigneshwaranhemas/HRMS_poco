<?php


namespace App\Repositories;


interface  IBuddyrepositories{

  public function get_candidate_info($id);
  public function get_feedback_info($id);




}

?>

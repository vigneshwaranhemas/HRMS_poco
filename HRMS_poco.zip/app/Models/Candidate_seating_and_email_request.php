<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Candidate_seating_and_email_request extends Model
{
    protected $gaurded=[];
    protected $table="candidate_seating_and_email_requests";
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BuddyFeedbackModel extends Model
{
    protected $gaurded=[];
    protected $table="buddy_feedback_models";
}

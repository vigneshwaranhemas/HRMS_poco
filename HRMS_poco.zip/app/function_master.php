<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class function_master extends Model
{
    protected $gaurded = [];
    protected $table = "function_masters";
}

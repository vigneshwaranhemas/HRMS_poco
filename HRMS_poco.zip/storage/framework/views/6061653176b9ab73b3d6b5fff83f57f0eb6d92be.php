<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

      
                <p><b>Dear HR Team,</b></p>

                <p>Please note this, <?php echo e($candidate_name); ?> Sended a Request to Update this ID Card Verfication mail.</p>

                <p><b>Thank you,</b></p>
                <p><?php echo e($candidate_name); ?> - HEPL</p>
      


</body>
</html>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\emails\id_card_submit_can.blade.php ENDPATH**/ ?>
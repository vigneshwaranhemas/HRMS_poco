<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

                <p><b>Dear   "{{$supervisor_name}},</b></p>

                <p>{{$candidate_name}}  has joined with your department in the role of {{$candidate_position}} as on {{$doj}}, today..</p>
                <p>Please note that Official Email ID is {{$hr_suggest_email}}.  Personal Email ID is {{$candidate_email}}. </p>
                <p>Contact Number is {{$candidate_mobile}} ."Onboarding, Induction & Joining Formalities have been completed and handing over to you.</p>

                <p><b>Thank you,</b></p>
                <p>HR OP.S Team - HEPL</p>



</body>
</html>
{{-- LMS ID is ".$can_action_info['lms_inp'] --}}

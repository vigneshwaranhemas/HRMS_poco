<?php $__env->startSection('title', 'Premium Admin Template'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="../assets/css/fontawesome.css">
    <!-- ico-font-->
    <link rel="stylesheet" type="text/css" href="../assets/css/icofont.css">
    <!-- Themify icon-->
    <link rel="stylesheet" type="text/css" href="../assets/css/themify.css">
    <!-- Feather icon-->
    <link rel="stylesheet" type="text/css" href="../assets/css/feather-icon.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/animate.css">
    <!-- Plugins css start-->
    <link rel="stylesheet" type="text/css" href="../assets/css/datatables.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/owlcarousel.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/rating.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/pe7-icon.css">
    <!-- Plugins css Ends-->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <link id="color" rel="stylesheet" href="../assets/css/color-1.css" media="screen">
    <!-- Responsive css-->
    <link rel="stylesheet" type="text/css" href="../assets/css/responsive.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    .modal
    {
        padding-right: 59% !important;
    }
    .table thead th
    {
        border-bottom: 2px solid #dee2e6 !important;
        border: 2px solid #dee2e6;
        width: 1px;
    }
    .table tr
    {
        border-bottom: 2px solid #dee2e6 !important;
        border: 2px solid #dee2e6;
    }
    .table td
    {
        border-bottom: 2px solid #dee2e6 !important;
        border: 2px solid #dee2e6;
    }
    .word-warpped
    {
        word-break: break-word;
        max-width: 160px;
        min-width: 160px;
        /* max-width: 160px; */
        min-width: 356px;
    }
    .remark
    {
        min-width: 286px;

    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2>HR Buddy</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">Dashboard</li>
	<li class="breadcrumb-item active">Default</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Container-fluid starts-->
 <div class="container-fluid">
    <div class="row">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" id="token">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                <div class="dt-ext table-responsive">
                    <table class="display" id="Buddy_info_table">
                    <thead>
                        <tr>
                        <th>EmployeeId</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile Number</th>
                        <th>FeedBack</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($candidate_info)>0): ?>
                        <?php $__currentLoopData = $candidate_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->cdID); ?></td>
                            <td><?php echo e($item->candidate_name); ?></td>
                            <td><?php echo e($item->candidate_email); ?></td>
                            <td><?php echo e($item->candidate_mobile); ?></td>
                            <td>
                                <button onclick=showAdd("<?php echo e($item->cdID); ?>") aria-expanded="false" data-toggle="dropdown" class="btn btn-default dropdown-toggle waves-effect waves-light" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                            </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                   <tr><td>No Data Available</td></tr>;
            <?php endif; ?>
                        
                    </tbody>
                    </table>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Container-fluid Ends-->

<div class="modal fade" id="edit-column-form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 261%;">
            <div class="modal-body">
                <table class="table table-custom dtable-striped table-bordered" style="width: -webkit-fill-available;">
                    <thead>
                        <tr>
                            <th scope="col" rowspan="2">No</th>
                            <th scope="col" rowspan="2">Question / Query</th>
                            <th scope="col" colspan="6" class="text-center">Response</th>
                        </tr>
                        <tr>
                            <th scope="col">STRONGLY DISAGREE</th>
                            <th scope="col">DISAGREE</th>
                            <th scope="col">NEITEHR AGREE NOR DISAGREE</th>
                            <th scope="col">AGREE</th>
                            <th scope="col">STRONGLY AGREE</th>
                            <th scope="col">Remarks</th>
                        </tr>
                        </thead>

                    <tbody id="buddy_feedback_tableId">
                        <tr>
                        <th scope="row">1</th>
                        <td><p class="word-warpped">My Buddy interacted with me pleasantly during the welcome session which helped me be comfortable and  bond well</p> </td>

                        <td>
                            <div class="text-center">
                                <p style="color:green" class="fa fa-check"></p>
                            </div>
                        </td>

                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>

                        <td class="remark">none</td>


                        </tr>
                        
                    </tbody>
                </table>

                <div class="modal-body" id="textarea_div">

                </div>
                
                <!-- <div class="row" style="margin-top: 40px;">

                    <div class="col-md-12">
                        <h6>7.  What went very well, during  my interactions with my Buddy</h6>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card">
                            <div class="card-body grid-showcase">

                                <p>No </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card">
                            <div class="card-body grid-showcase">
                                <p>Auto-layout for flexbox grid columns also means you can set the width of one column and have the sibling columns automatically resize around it. You may use predefined grid classes (as shown below), grid mixins, or inline widths. Note that the other columns will resize no matter the width of the center column.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card">
                            <div class="card-body grid-showcase">
                                <p>Auto-layout for flexbox grid columns also means you can set the width of one column and have the sibling columns automatically resize around it. You may use predefined grid classes (as shown below), grid mixins, or inline widths. Note that the other columns will resize no matter the width of the center column.</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row" style="margin-top: 40px;">

                    <div class="col-md-12">
                        <h6>8.  What went very well, during  my interactions with my Buddy</h6>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card">
                            <div class="card-body grid-showcase">
                                <p>Auto-layout for flexbox grid columns also means you can set the width of one column and have the sibling columns automatically resize around it. You may use predefined grid classes (as shown below), grid mixins, or inline widths. Note that the other columns will resize no matter the width of the center column.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card">
                            <div class="card-body grid-showcase">
                                <p>Auto-layout for flexbox grid columns also means you can set the width of one column and have the sibling columns automatically resize around it. You may use predefined grid classes (as shown below), grid mixins, or inline widths. Note that the other columns will resize no matter the width of the center column.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card">
                            <div class="card-body grid-showcase">
                                <p>Auto-layout for flexbox grid columns also means you can set the width of one column and have the sibling columns automatically resize around it. You may use predefined grid classes (as shown below), grid mixins, or inline widths. Note that the other columns will resize no matter the width of the center column.</p>
                            </div>
                        </div>

                    </div>


                </div> -->

            </div>
        </div>
    </div>
</div>

<!-- Container-fluid Ends-->
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../pro_js/buddy/buddy.js"></script>
<?php $__env->startSection('script'); ?>
    <!-- latest jquery-->

    <script>
        // function showAdd() {
        //     $('#edit-column-form').modal('show');
        // }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.simple.buddy_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/buddy/index.blade.php ENDPATH**/ ?>
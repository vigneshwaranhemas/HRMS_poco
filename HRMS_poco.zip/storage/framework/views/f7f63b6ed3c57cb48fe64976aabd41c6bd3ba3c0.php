
<?php $__env->startSection('title', 'Candidate Seating And IdCard '); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url("assets/css/datatables.css")); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/datatable-extension.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2><span>Candidate Seating And IdCard  </span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">Candidate Seating And IdCard </li>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="col-sm-12 col-xl-12 xl-100">
    <div class="card">

        <div class="card-body">
           <ul class="nav nav-tabs nav-material" id="top-tab" role="tablist">
              <li class="nav-item">
                 <a class="nav-link active" id="top-home-tab" data-toggle="tab" href="#top-home" role="tab" aria-controls="top-home" aria-selected="true"><i class="icofont icofont-ui-home"></i>Pending</a>
                 <div class="material-border"></div>
              </li>
              <li class="nav-item">
                 <a class="nav-link" id="profile-top-tab" data-toggle="tab" href="#top-profile" role="tab" aria-controls="top-profile" aria-selected="false"><i class="icofont icofont-man-in-glasses"></i>Completed</a>
                 <div class="material-border"></div>
              </li>

           </ul>
           <div class="tab-content" id="top-tabContent">
              <div class="tab-pane fade show active" id="top-home" role="tabpanel" aria-labelledby="top-home-tab">
                 <div class="col-sm-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="dt-ext table-responsive">
                             <table class="display" id="export-button">
                                 <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Enployee ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile Number</th>
                                        <th>Seating Status</th>
                                        <th>Idcard Status</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php if(count($seating_info['pending'])>0): ?>
                                         <?php $i=1;?>
                                         <?php $__currentLoopData = $seating_info['pending']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($data['empId']); ?></td>
                                            <td><?php echo e($data['username']); ?></td>
                                            <td><?php echo e($data['email']); ?></td>
                                            <td><?php echo e($data['contact_no']); ?></td>
                                             <?php if($data['Seating_Request']==1): ?>
                                               <td><span class="badge badge-success">Alloted</span></td>
                                             <?php else: ?>
                                               <td><span class="badge badge-warning">Pending</span></td>
                                             <?php endif; ?>
                                             <?php if($data['IdCard_status']==1): ?>
                                             <td><span class="badge badge-success">Created</span></td>
                                             <?php else: ?>
                                                <td><span class="badge badge-warning">Pending</span></td>
                                             <?php endif; ?>

                                         </tr>
                                         <?php $i++;?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
              </div>
              <div class="tab-pane fade" id="top-profile" role="tabpanel" aria-labelledby="profile-top-tab">
                 <div class="col-sm-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="dt-ext table-responsive">
                             <table class="display" id="export-button1">
                                 <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Employee ID</th>
                                        <th>Name</th>
                                        <th>EMmail</th>
                                        <th>Mobile Number</th>
                                        <th>Seating Status</th>
                                        <th>Idcard Status</th>
                                    </tr>
                                 </thead>
                                 <tbody>

                                    <?php if(count($seating_info['completed'])>0): ?>
                                         <?php $i=1;?>
                                         <?php $__currentLoopData = $seating_info['completed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($data['empId']); ?></td>
                                            <td><?php echo e($data['username']); ?></td>
                                            <td><?php echo e($data['email']); ?></td>
                                            <td><?php echo e($data['contact_no']); ?></td>
                                             <?php if($data['Seating_Request']==1): ?>
                                               <td><span class="badge badge-success">Alloted</span></td>
                                             <?php else: ?>
                                               <td><span class="badge badge-warning">Pending</span></td>
                                             <?php endif; ?>
                                             <?php if($data['IdCard_status']==1): ?>
                                             <td><span class="badge badge-success">Created</span></td>
                                             <?php else: ?>
                                                <td><span class="badge badge-warning">Pending</span></td>
                                             <?php endif; ?>

                                         </tr>
                                         <?php $i++;?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>

           </div>
          </div>
        </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.simple.hr_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\HRSS\Seating.blade.php ENDPATH**/ ?>
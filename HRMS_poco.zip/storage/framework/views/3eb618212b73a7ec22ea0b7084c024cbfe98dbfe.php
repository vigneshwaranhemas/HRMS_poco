
<?php $__env->startSection('title', 'EmailId Creation'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url("assets/css/datatables.css")); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/datatable-extension.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<style>
    .tdtextwidth{
        width: 163px;
    }
    .bg-warning
    {
        background-color: #7e37d8 !important;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
	<h2><span>EmailId Creation</span></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
   <li class="breadcrumb-item">EmailId Creation</li>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
               <div class="card-body">
                 <button type="button" style="margin-left: 1092px;margin-bottom:13px;" class="btn btn-pill btn-primary"  id="EmailCreationBtn">Submit</button>

                  <div class="dt-ext table-responsive">
                    <table class="display" id="export-button">
                        <thead>
                           <tr>
                              <th>S.No</th>
                              <th>#</th>
                              <th>Employee ID</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Status</th>
                              <th>HR Suggested Email</th>
                              <th>Asset Type</th>
                           </tr>
                        </thead>
                        <tbody id="emailIdCreation">
                        </tbody>
                     </table>
                     <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" id="token">
                     
                  </div>
               </div>
            </div>
         </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
var email_url="Candidate_Email_Creation";
var status_update_url="Candidate_Email_Status_update";
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo e(url('pro_js/HRSS/CandidateEmailCreation.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.simple.hr_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\HRSS\EmailIdCreation.blade.php ENDPATH**/ ?>
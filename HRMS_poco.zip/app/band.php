<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class band extends Model
{
    protected $gaurded = [];
    protected $table = "bands";
}

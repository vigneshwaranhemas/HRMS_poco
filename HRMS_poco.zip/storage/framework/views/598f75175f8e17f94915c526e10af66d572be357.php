<h4>Dear <?php echo e($name); ?></h4>
<p>We wish you a very <span style="color:blue; font-size:16px;">Happy Birthday!!<span></p>
<p>We hope that you have a great year and accomplish all the fabulous goals you have set for yourself.</p>
<p>May the coming years be filled with happiness, peace, and love.</p>
<p>Have a great life ahead.</p><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\birthday\mail.blade.php ENDPATH**/ ?>
<!-- latest jquery-->
<script src="<?php echo e(route('/')); ?>/assets/js/jquery-3.5.1.min.js"></script>
<script src="<?php echo e(route('/')); ?>/assets/js/bootstrap/popper.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo e(route('/')); ?>/assets/js/bootstrap/bootstrap.js"></script>
<!-- feather icon js-->
<script src="<?php echo e(route('/')); ?>/assets/js/icons/feather-icon/feather.min.js"></script>
<script src="<?php echo e(route('/')); ?>/assets/js/icons/feather-icon/feather-icon.js"></script>
<!-- Sidebar jquery-->
<script src="<?php echo e(route('/')); ?>/assets/js/sidebar-menu.js"></script>
<script src="<?php echo e(route('/')); ?>/assets/js/config.js"></script>
<script src="<?php echo e(route('/')); ?>/assets/js/chat-menu.js"></script>
<?php echo $__env->yieldContent('script'); ?>	
<!-- Plugins JS Ends-->
<!-- Theme js-->
<script src="<?php echo e(route('/')); ?>/assets/js/script.js"></script>
<script src="<?php echo e(route('/')); ?>/assets/js/theme-customizer/customizer.js"></script>
<!-- login js--><?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\layouts\box\script.blade.php ENDPATH**/ ?>
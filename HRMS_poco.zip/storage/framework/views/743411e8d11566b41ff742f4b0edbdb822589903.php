<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

      
                <p><b>Dear <?php echo e($candidate_name); ?>,</b></p>

                <p> We have reviewed your submissions and have reverted to you with observations. </p>

                <p>Kindly resubmit after revising the information.</p>

                <p><b>Thank you,</b></p>
                <p>HR Team- HEPL</p>
      


</body>
</html>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\emails\hr_idcard_revert.blade.php ENDPATH**/ ?>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailCreationModel extends Model
{
    protected $gaurded=[];
    protected $table="candidate_email_request";
}

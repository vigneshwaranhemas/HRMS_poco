


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Password Change</title>
</head>
<body>

      
                <p><b>Dear <?php echo e($candidate_name); ?>,</b></p>

                <p> Click the Below link to Change Password </p><a href="<?php echo e(url('/email_pass?token='.$passcode_token.'')); ?>">Change your Password Link</a>

                <p><b>Thank you,</b></p>
                <p>HR Team- HEPL</p>
      


</body>
</html>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views\emails\forget_password.blade.php ENDPATH**/ ?>
<div class="iconsidebar-menu iconbar-mainmenu-close">
    <div class="sidebar">
       <ul class="iconMenu-bar custom-scrollbar" id="sidebar_data">
                
       </ul>
    </div>
 </div>
<?php /**PATH C:\xampp\htdocs\HRMS_poco\resources\views/layouts/simple/common_sidebar.blade.php ENDPATH**/ ?>